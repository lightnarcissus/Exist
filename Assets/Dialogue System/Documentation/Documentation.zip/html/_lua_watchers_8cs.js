var _lua_watchers_8cs =
[
    [ "LuaWatchers", "class_pixel_crushers_1_1_dialogue_system_1_1_lua_watchers.html", "class_pixel_crushers_1_1_dialogue_system_1_1_lua_watchers" ],
    [ "LuaWatchFrequency", "_lua_watchers_8cs.html#afcb2e80e6355015ae68885da8bd7a101", [
      [ "EveryUpdate", "_lua_watchers_8cs.html#afcb2e80e6355015ae68885da8bd7a101a2e67b131fe2a9074772ebc6a8d66c657", null ],
      [ "EveryDialogueEntry", "_lua_watchers_8cs.html#afcb2e80e6355015ae68885da8bd7a101a5b9026814640b7c91a63d056b17b76a9", null ],
      [ "EndOfConversation", "_lua_watchers_8cs.html#afcb2e80e6355015ae68885da8bd7a101aefe1166ce669e839135684ed179199f0", null ]
    ] ]
];