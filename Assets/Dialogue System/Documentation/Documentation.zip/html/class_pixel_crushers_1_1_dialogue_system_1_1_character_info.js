var class_pixel_crushers_1_1_dialogue_system_1_1_character_info =
[
    [ "CharacterInfo", "class_pixel_crushers_1_1_dialogue_system_1_1_character_info.html#a81d7d1d13b5e6671144dd61c8b9721d8", null ],
    [ "characterType", "class_pixel_crushers_1_1_dialogue_system_1_1_character_info.html#abf4f8eb03b222bd97675882a7f6abe8f", null ],
    [ "id", "class_pixel_crushers_1_1_dialogue_system_1_1_character_info.html#a084965769424178108156cfc6dfa169e", null ],
    [ "nameInDatabase", "class_pixel_crushers_1_1_dialogue_system_1_1_character_info.html#a5d31f2820cdbf2967cf0cd5bb70bc765", null ],
    [ "portrait", "class_pixel_crushers_1_1_dialogue_system_1_1_character_info.html#ad805da1fa87a26443206f07d375f0799", null ],
    [ "transform", "class_pixel_crushers_1_1_dialogue_system_1_1_character_info.html#a29aaee49ceb4aae68ccef102221c05f5", null ],
    [ "IsNPC", "class_pixel_crushers_1_1_dialogue_system_1_1_character_info.html#a26f3dcab09db8026a6538e67402c023d", null ],
    [ "IsPlayer", "class_pixel_crushers_1_1_dialogue_system_1_1_character_info.html#ae0dd8b2d312216dd709bf3cb048388ca", null ],
    [ "Name", "class_pixel_crushers_1_1_dialogue_system_1_1_character_info.html#a83fb03e68725d7f52217c51e8a2f0167", null ]
];