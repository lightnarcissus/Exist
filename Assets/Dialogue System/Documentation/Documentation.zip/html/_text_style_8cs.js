var _text_style_8cs =
[
    [ "TextStyle", "_text_style_8cs.html#a9d2343293881fe8d686527a19493a98b", [
      [ "None", "_text_style_8cs.html#a9d2343293881fe8d686527a19493a98ba6adf97f83acf6453d4a6a4b1070f3754", null ],
      [ "Shadow", "_text_style_8cs.html#a9d2343293881fe8d686527a19493a98ba3f39588bb19e28051d9aedfbb170025c", null ],
      [ "Outline", "_text_style_8cs.html#a9d2343293881fe8d686527a19493a98ba606b51cc1c9d0b4af394419a22f2ff1f", null ]
    ] ]
];