var _conversation_view_8cs =
[
    [ "ConversationView", "class_pixel_crushers_1_1_dialogue_system_1_1_conversation_view.html", "class_pixel_crushers_1_1_dialogue_system_1_1_conversation_view" ],
    [ "DialogueEntrySpokenDelegate", "_conversation_view_8cs.html#ad76ca50cbbe6b0caa03416f6b0a44274", null ]
];