var class_pixel_crushers_1_1_dialogue_system_1_1_abstract_u_i_subtitle_controls =
[
    [ "ClearSubtitle", "class_pixel_crushers_1_1_dialogue_system_1_1_abstract_u_i_subtitle_controls.html#a0f85acc3d554e3a18e62f198d8bd058b", null ],
    [ "SetSubtitle", "class_pixel_crushers_1_1_dialogue_system_1_1_abstract_u_i_subtitle_controls.html#a0bdb08b8ea1443e25ad71b42196fbc26", null ],
    [ "ShowSubtitle", "class_pixel_crushers_1_1_dialogue_system_1_1_abstract_u_i_subtitle_controls.html#a2a47b362e754e24093f8ae7d90fc2b60", null ],
    [ "HasText", "class_pixel_crushers_1_1_dialogue_system_1_1_abstract_u_i_subtitle_controls.html#a8fbba81e36a766ee7b8f3c5ba6193f6b", null ]
];